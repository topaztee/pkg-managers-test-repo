exports.foo = require('b').foo;
